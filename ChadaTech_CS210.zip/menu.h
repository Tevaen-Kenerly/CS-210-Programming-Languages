#pragma once
using namespace std;
#include <iostream>
#ifndef menu_h
#define menu_h

//delcares functions for displaying and processing the menu

void menu();
int userChoice();
int addHour(int hour);
int addMinute(int minute);
int addSecond(int second);

#endif


